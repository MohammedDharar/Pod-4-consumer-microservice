package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
class GlobalExceptionHandlerTest {

	@Autowired
	GlobalExceptionHandler globalExceptionHandler;

	ApiErrorResponse apiErrorResponse;

	@BeforeEach
	void setUp() {
		apiErrorResponse = new ApiErrorResponse();
	}

	

	@Test
	void handlesConsumerBusinessNotfoundExceptionTest() {
		ConsumerBusinessNotfoundException  consumerBusinessNotfoundException  = new ConsumerBusinessNotfoundException (
				"Quotes Not found");
		globalExceptionHandler.handleConsumerBusinessNotfoundException(consumerBusinessNotfoundException);
		apiErrorResponse.setMessage(consumerBusinessNotfoundException.getMessage());
		apiErrorResponse.setLocalizedMessage(consumerBusinessNotfoundException.getLocalizedMessage());
		ResponseEntity<?> entity = new ResponseEntity<>(apiErrorResponse, HttpStatus.UNAUTHORIZED);
		assertEquals(401, entity.getStatusCode().value());
	}
	@Test
	void handlesConsumerPropertyExceptionTest() {
		ConsumerPropertyException  consumerPropertyException = new ConsumerPropertyException (
				"Quotes Not found");
		globalExceptionHandler.handleConsumerPropertyException(consumerPropertyException );
		apiErrorResponse.setMessage(consumerPropertyException .getMessage());
		apiErrorResponse.setLocalizedMessage(consumerPropertyException .getLocalizedMessage());
		ResponseEntity<?> entity = new ResponseEntity<>(apiErrorResponse, HttpStatus.UNAUTHORIZED);
		assertEquals(401, entity.getStatusCode().value());
	}
}

package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerBusinessNotfoundExceptionTest extends Exception{

	@Test
	void ConsumerBusinessNotfoundExceptionTest() {
		ConsumerBusinessNotfoundException consumerBusinessNotfoundException=new ConsumerBusinessNotfoundException("CS2- Consumer Not Found");
		assertEquals("CS2- Consumer Not Found",consumerBusinessNotfoundException.getMessage());
	}

}

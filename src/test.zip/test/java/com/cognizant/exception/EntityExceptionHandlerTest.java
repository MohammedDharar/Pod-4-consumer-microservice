package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.context.request.WebRequest;

@SpringBootTest
public class EntityExceptionHandlerTest {
	
	/**
	 * @Test EntityExceptionHandler Class
	 * @author POD-4
	 */
	    @Test
	    public void testEntityException1(){
	      WebRequest web = null;
	      ConsumerBusinessNotfoundException consumer= new ConsumerBusinessNotfoundException("Consumer Business Not Found");
	      EntityExceptionHandler exp = new EntityExceptionHandler();
	      assertEquals(500, exp.handleAnyException(consumer, web).getStatusCodeValue());
	    }
	    @Test
	    public void testEntityException(){
	      WebRequest web = null;
	      ConsumerPropertyException consumer= new ConsumerPropertyException("Consumer Business Not Found");
	      EntityExceptionHandler exp = new EntityExceptionHandler();
	      assertEquals(500, exp.handleAnyException(consumer, web).getStatusCodeValue());
	    }
	}

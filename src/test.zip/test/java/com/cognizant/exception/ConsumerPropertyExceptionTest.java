package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerPropertyExceptionTest {

	@Test
	void ConsumerPropertyExceptionTest() {
		ConsumerPropertyException consumerPropertyException=new ConsumerPropertyException("CS1- property Not Found.");
		assertEquals("CS1- property Not Found.",consumerPropertyException.getMessage());
	}

}

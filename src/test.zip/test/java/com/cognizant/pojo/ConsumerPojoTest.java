package com.cognizant.pojo;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ConsumerPojoTest {
	private ConsumerPojo consumerPojo;
	
	@Test
	public void consumerPojoTest() {
		consumerPojo=new ConsumerPojo();
		
		consumerPojo.setConsumerId((Integer)2);
		consumerPojo.setFirstName("first name");
		consumerPojo.setLastName("last name");
		consumerPojo.setDob(new Date(1998-03-26));
		consumerPojo.setBusinessName("business name");
		consumerPojo.setPanDetails("pan details");
		consumerPojo.setEmail("email");
		consumerPojo.setPhone("phone");
		consumerPojo.setAddress("address");
		consumerPojo.setAgentName("agent name");
		consumerPojo.setAgentId((Integer)1);
		
		consumerPojo.setBusinessId((Integer)10);
		consumerPojo.setBusinessCategory("Manufacturer");
		consumerPojo.setBusinessTurnOver((Long)2500000L);
		consumerPojo.setCapitalInvested((Long)20000L);
		consumerPojo.setTotalEmployees((Integer)25);
		consumerPojo.setBusinessValue((Integer)2);
		consumerPojo.setBusinessAge((Integer)5);
		
		assertEquals((Integer)2,consumerPojo.getConsumerId());
		assertEquals("first name",consumerPojo.getFirstName());
		assertEquals("last name",consumerPojo.getLastName());
		assertEquals(new Date(1998-03-26),consumerPojo.getDob());
		assertEquals("business name",consumerPojo.getBusinessName());
		assertEquals("pan details",consumerPojo.getPanDetails());
		assertEquals("email",consumerPojo.getEmail());
		assertEquals("phone",consumerPojo.getPhone());
		assertEquals("address",consumerPojo.getAddress());
		assertEquals("agent name",consumerPojo.getAgentName());
		assertEquals((Integer)1,consumerPojo.getAgentId());
		
		assertEquals((Integer)10,consumerPojo.getBusinessId());
		assertEquals("Manufacturer",consumerPojo.getBusinessCategory());
		assertEquals((Long)2500000L,consumerPojo.getBusinessTurnOver());
		assertEquals((Long)20000L,consumerPojo.getCapitalInvested());
		assertEquals((Integer)25,consumerPojo.getTotalEmployees());
		assertEquals((Integer)2,consumerPojo.getBusinessValue());
		assertEquals((Integer)5,consumerPojo.getBusinessAge());	
	}
	
	@Test
	public void testConsumerPojoAllArgument() {
		consumerPojo=new ConsumerPojo((Integer)2,"first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1,
				(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5);
		
		assertEquals((Integer)2,consumerPojo.getConsumerId());
		assertEquals("first name",consumerPojo.getFirstName());
		assertEquals("last name",consumerPojo.getLastName());
		assertEquals(new Date(1998-03-26),consumerPojo.getDob());
		assertEquals("business name",consumerPojo.getBusinessName());
		assertEquals("pan details",consumerPojo.getPanDetails());
		assertEquals("email",consumerPojo.getEmail());
		assertEquals("phone",consumerPojo.getPhone());
		assertEquals("address",consumerPojo.getAddress());
		assertEquals("agent name",consumerPojo.getAgentName());
		assertEquals((Integer)1,consumerPojo.getAgentId());
		
		assertEquals((Integer)10,consumerPojo.getBusinessId());
		assertEquals("Manufacturer",consumerPojo.getBusinessCategory());
		assertEquals((Long)2500000L,consumerPojo.getBusinessTurnOver());
		assertEquals((Long)20000L,consumerPojo.getCapitalInvested());
		assertEquals((Integer)25,consumerPojo.getTotalEmployees());
		assertEquals((Integer)2,consumerPojo.getBusinessValue());
		assertEquals((Integer)5,consumerPojo.getBusinessAge());	
	}
}

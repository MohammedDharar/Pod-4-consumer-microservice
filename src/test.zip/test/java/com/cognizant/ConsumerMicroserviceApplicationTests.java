package com.cognizant;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerMicroserviceApplicationTests {

	@Test
	void contextLoads() throws IOException{
		ConsumerMicroserviceApplication.main(new String[] {});
		assertTrue(true);
	}

}

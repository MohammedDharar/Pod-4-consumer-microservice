package com.cognizant.model;

import static org.junit.Assert.assertEquals;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ConsumerTest {
	private Consumer consumer;
	
	@Test
	public void testConsumerDetails() {
		consumer=new Consumer();
		consumer.setFirstName("first name");
		consumer.setLastName("last name");
		consumer.setDob(new Date(1998-03-26));
		consumer.setBusinessName("business name");
		consumer.setPanDetails("pan details");
		consumer.setEmail("email");
		consumer.setPhone("phone");
		consumer.setAddress("address");
		consumer.setAgentName("agent name");
		consumer.setAgentId((Integer)1);
		
		assertEquals("first name",consumer.getFirstName());
		assertEquals("last name",consumer.getLastName());
		assertEquals(new Date(1998-03-26),consumer.getDob());
		assertEquals("business name",consumer.getBusinessName());
		assertEquals("pan details",consumer.getPanDetails());
		assertEquals("email",consumer.getEmail());
		assertEquals("phone",consumer.getPhone());
		assertEquals("address",consumer.getAddress());
		assertEquals("agent name",consumer.getAgentName());
		assertEquals((Integer)1,consumer.getAgentId());
	}
	
	@Test
	public void testConsumerAllArguments() {
		consumer=new Consumer("first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1);
		assertEquals("first name",consumer.getFirstName());
		assertEquals("last name",consumer.getLastName());
		assertEquals(new Date(1998-03-26),consumer.getDob());
		assertEquals("business name",consumer.getBusinessName());
		assertEquals("pan details",consumer.getPanDetails());
		assertEquals("email",consumer.getEmail());
		assertEquals("phone",consumer.getPhone());
		assertEquals("address",consumer.getAddress());
		assertEquals("agent name",consumer.getAgentName());
		assertEquals((Integer)1,consumer.getAgentId());
	}
}

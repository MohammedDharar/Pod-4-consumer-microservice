package com.cognizant.model;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BusinessTest {
	private Business business;
	
	@Test
	public void businessTest() {
		business=new Business();
		
		business.setConsumerId((Integer)2);
		business.setBusinessId((Integer)10);
		business.setBusinessCategory("Manufacturer");
		business.setBusinessTurnOver((Long)2500000L);
		business.setCapitalInvested((Long)20000L);
		business.setTotalEmployees((Integer)25);
		business.setBusinessValue((Integer)2);
		business.setBusinessAge((Integer)5);
		
		assertEquals((Integer)2,business.getConsumerId());
		assertEquals((Integer)10,business.getBusinessId());
		assertEquals("Manufacturer",business.getBusinessCategory());
		assertEquals((Long)2500000L,business.getBusinessTurnOver());
		assertEquals((Long)20000L,business.getCapitalInvested());
		assertEquals((Integer)25,business.getTotalEmployees());
		assertEquals((Integer)2,business.getBusinessValue());
		assertEquals((Integer)5,business.getBusinessAge());	
	}
	
	@Test
	public void testBusinessAllArguments() {
		business=new Business((Integer)2,(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5);
		
		assertEquals((Integer)2,business.getConsumerId());
		assertEquals((Integer)10,business.getBusinessId());
		assertEquals("Manufacturer",business.getBusinessCategory());
		assertEquals((Long)2500000L,business.getBusinessTurnOver());
		assertEquals((Long)20000L,business.getCapitalInvested());
		assertEquals((Integer)25,business.getTotalEmployees());
		assertEquals((Integer)2,business.getBusinessValue());
		assertEquals((Integer)5,business.getBusinessAge());	
	}
}

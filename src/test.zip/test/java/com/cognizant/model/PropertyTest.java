package com.cognizant.model;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PropertyTest {
	private Property property;
	
	@Test
	public void propertyTest() {
		property=new Property();
		
		property.setBusinessId((Integer)10);
		property.setInsuranceType("Business");
		property.setPropertyType("Warehouse");
		property.setAnnualDepreciationValue((Long)20000L);
		property.setPropertyValue((int)2);
		property.setBuildingsqft("30000");
		property.setBuildingType("Rental");
		property.setBuildingAge((Integer)3);
		property.setCostOfAsset((Long)200000L);
		property.setSalvageValue((Long)180000L);
		property.setUsefulLifeOfAsset((Integer)3);
		
		assertEquals((Integer)10,property.getBusinessId());
		assertEquals("Business",property.getInsuranceType());
		assertEquals("Warehouse",property.getPropertyType());
		assertEquals((Long)20000L,property.getAnnualDepreciationValue());
		assertEquals((int)2,property.getPropertyValue());
		assertEquals("30000",property.getBuildingsqft());
		assertEquals("Rental",property.getBuildingType());
		assertEquals((Integer)3,property.getBuildingAge());
		assertEquals((Long)200000L,property.getCostOfAsset());
		assertEquals((Long)180000L,property.getSalvageValue());
		assertEquals((Integer)3,property.getUsefulLifeOfAsset());
	}
	
	@Test
	public void testPropertyAllArguments() {
		property=new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3);
		
		assertEquals((Integer)10,property.getBusinessId());
		assertEquals("Business",property.getInsuranceType());
		assertEquals("Warehouse",property.getPropertyType());
		assertEquals((Long)20000L,property.getAnnualDepreciationValue());
		assertEquals((int)2,property.getPropertyValue());
		assertEquals("30000",property.getBuildingsqft());
		assertEquals("Rental",property.getBuildingType());
		assertEquals((Integer)3,property.getBuildingAge());
		assertEquals((Long)200000L,property.getCostOfAsset());
		assertEquals((Long)180000L,property.getSalvageValue());
		assertEquals((Integer)3,property.getUsefulLifeOfAsset());
	}
}

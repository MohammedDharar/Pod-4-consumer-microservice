package com.cognizant.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.model.Business;
import com.cognizant.model.Consumer;
import com.cognizant.model.Property;
import com.cognizant.pojo.ConsumerPojo;
import com.cognizant.repository.BusinessRepository;
import com.cognizant.repository.ConsumerRepository;
import com.cognizant.repository.PropertyRepository;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class ConsumerMicroservicesImplTest {

	@Mock
	private ConsumerRepository consumerRepository;
	
	@Mock
	private BusinessRepository businessRepository;
	
	@Mock
	private PropertyRepository propertyRepository;
	
	@InjectMocks
	private ConsumerMicroservicesImpl consumerMicroservicesImpl;
	
	ConsumerPojo consumerPojo;
	Consumer consumer;
	Business business;
	Property property;
	
	@BeforeEach
	void init() {
		consumerPojo=new ConsumerPojo((Integer)2,"first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1,
				(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5);
		Consumer consumer=new Consumer(consumerPojo.getFirstName(),consumerPojo.getLastName(),consumerPojo.getDob(),consumerPojo.getBusinessName(),consumerPojo.getPanDetails(),consumerPojo.getEmail(),consumerPojo.getPhone(),consumerPojo.getAddress(),consumerPojo.getAgentName(),consumerPojo.getAgentId());
		consumerRepository.save(consumer);
		Business business=new Business(consumer.getConsumerId(), consumerPojo.getBusinessId(),consumerPojo.getBusinessCategory(),consumerPojo.getBusinessTurnOver(),consumerPojo.getCapitalInvested(),consumerPojo.getTotalEmployees(),(Integer)2,consumerPojo.getBusinessAge());
		businessRepository.save(business);
		property=new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3);
		propertyRepository.save(property);
	}
	
	@Test
	public void testCreateConsumerBusiness() {
		
		
		Consumer consumer=new Consumer(consumerPojo.getFirstName(),consumerPojo.getLastName(),consumerPojo.getDob(),consumerPojo.getBusinessName(),consumerPojo.getPanDetails(),consumerPojo.getEmail(),consumerPojo.getPhone(),consumerPojo.getAddress(),consumerPojo.getAgentName(),consumerPojo.getAgentId());
		when(consumerRepository.save(consumer)).thenReturn(consumer);
		
		Business business=new Business(consumer.getConsumerId(), consumerPojo.getBusinessId(),consumerPojo.getBusinessCategory(),consumerPojo.getBusinessTurnOver(),consumerPojo.getCapitalInvested(),consumerPojo.getTotalEmployees(),(Integer)2,consumerPojo.getBusinessAge());
		when(businessRepository.save(business)).thenReturn(business);
		
		assertEquals("Data has been Saved!","Data has been Saved!");
	}
	
	@Test
	public void testUpdateConsumerBusiness() {
		Consumer consumer1=new Consumer("first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1);

		consumer1.setConsumerId((Integer)2);
		
		Mockito.when(consumerRepository.findById(consumer1.getConsumerId())).thenReturn(
				Optional.of(new Consumer("first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1)));
	
		
		Business business1=new Business();
		
		Mockito.when(businessRepository.findByConsumerId(consumer1.getConsumerId())).thenReturn(
				new Business((Integer)2,(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5));
		
		consumer1.setFirstName("first name");
		consumer1.setLastName("last name");
		consumer1.setDob(new Date(1998-03-26));
		consumer1.setBusinessName("business name");
		consumer1.setPanDetails("pan details");  
		consumer1.setEmail("email");
		consumer1.setPhone("phone");
		consumer1.setAddress("address");
		consumer1.setAgentName("agent name");
		consumer1.setAgentId((Integer)1);
		
		consumerRepository.save(consumer1);
		
		business1.setBusinessCategory("Manufacturer");
		business1.setBusinessTurnOver((Long)2500000L);
		business1.setCapitalInvested((Long)20000L);
		business1.setTotalEmployees((Integer)25);
		business1.setBusinessValue((Integer)2);
		business1.setBusinessAge((Integer)5);
		
		businessRepository.save(business);
		
		assertEquals("Updated for Consumer ID ","Updated for Consumer ID ");

	}
	
	@Test
	public void testGetbusinessValue() {
		Integer businessValue=consumerMicroservicesImpl.getBusinessValue((Long)100000L, (Long)50000L);
		assertEquals((Integer)2,businessValue);
	}
	
	@Test
	public void testCreateBusinessProperty() {
		property=new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3);
		when(propertyRepository.save(property)).thenReturn(property);
		assertEquals("Business Propert Data Saved!","Business Propert Data Saved!");
	}
	
	@Test
	public void testUpdateBusinessProperty() {
		//property=new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3);
		
		Mockito.when(propertyRepository.findByBusinessId(property.getBusinessId())).thenReturn(
				new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3));
		
		//property.setBusinessId((Integer)10);
		property.setInsuranceType("Business");
		property.setPropertyType("Warehouse");
		property.setAnnualDepreciationValue((Long)20000L);
		property.setPropertyValue((int)2);
		property.setBuildingsqft("30000");
		property.setBuildingType("Rental");
		property.setBuildingAge((Integer)3);
		property.setCostOfAsset((Long)200000L);
		property.setSalvageValue((Long)180000L);
		property.setUsefulLifeOfAsset((Integer)3);
		
		propertyRepository.save(property);

		assertEquals("Updated for Business Property ","Updated for Business Property ");
	}
	
	@Test
	public void testAnnualDepreciatonValue() {
		Long annualDepreciatonValue=consumerMicroservicesImpl.getAnnualDepreciatonValue((Long)1000000L,(Long)800000L,(Integer)5);
		assertEquals((Long)40000L,(Long)40000L);
	}
	
	@Test
	public void testViewConsumerBusiness() {
		//Consumer consumer1=new Consumer("first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1);
		
		Mockito.when(consumerRepository.findById((Integer)2)).thenReturn(
				Optional.of(new Consumer("first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1)));
	
		Mockito.when(businessRepository.findByConsumerId((Integer)2)).thenReturn(
				new Business((Integer)2,(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5));
		
		consumerPojo=new ConsumerPojo((Integer)2,"first name","last name",new Date(1998-03-26),"business name","pan details","email","phone","address","agent name",(Integer)1,
				(Integer)10,"Manufacturer",(Long)2500000L,(Long)20000L,(Integer)25,(Integer)2,(Integer)5);
		
		assertEquals(consumerPojo,consumerPojo);
	}
	
	@Test
	public void testViewBusinessProperty() {
		Mockito.when(propertyRepository.findByBusinessId((Integer)10)).thenReturn(
				new Property((Integer)10,"Business","Warehouse",(Long)20000L,(int)2,"30000","Rental",(Integer)3,(Long)200000L,(Long)180000L,(Integer)3));
		
		assertEquals(property,property);
	}

}
